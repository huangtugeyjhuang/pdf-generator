package hyj.pdf.generator.ftpdf;

import hyj.pdf.generator.util.DataUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.VerticalAlignment;

public class MyTable {
	Rectangle tableR;
	List<PdfFormField> headerList = new ArrayList<PdfFormField>();
	List<PdfFormField> rowList = new ArrayList<PdfFormField>();
	Map<String, PdfFormField> rowAllMap = new HashMap<String, PdfFormField>();
	Map<String, Object> attrMap;
	List<Float> yList;
	List<Float> xList;
	/**
	 * 头（多行）
	 */
	Map<Float, List<PdfFormField>> headerYRowMap = new HashMap<Float, List<PdfFormField>>();
	/**
	 * 数据行
	 */
	Map<Float, List<PdfFormField>> rowYRowMap = new HashMap<Float, List<PdfFormField>>();
	private String name;
	public Table table;
	public boolean ischild = false;
	private Float borderW = 1f;
	private Integer tableType = 10;
	private Integer pageHeader = 10;
	private PdfDocument pdfDoc; 

	public MyTable( Object dataObject, PdfDiv pdfDiv, Map<String, PdfFormField> fieldMap, PdfDocument pdfDoc)
			throws Exception {
		this(false, dataObject, pdfDiv, fieldMap, pdfDoc);
	}
	
	public MyTable(boolean ischild, Object dataObject, PdfDiv pdfDiv, Map<String, PdfFormField> fieldMap, PdfDocument pdfDoc)
			throws Exception {
		super();
		this.pdfDoc = pdfDoc;
		//获取属性
		if (dataObject instanceof Map) {
			attrMap = (Map<String, Object>) dataObject;
		} else {
			attrMap = DataUtil.objToMap(dataObject);
		}		
		String name = pdfDiv.getName();
		PdfFormField tableFeild = fieldMap.get(name);
		
		PDFFieldAttr tableAttr = PDFFieldUtil.getPDFFieldAttr(tableFeild);
		if (tableAttr != null) {
			if (tableAttr.getTableType() != null) {
				tableType = tableAttr.getTableType();
			}
			pageHeader = tableAttr.getPageHeader()==null?10:tableAttr.getPageHeader();
		}
		
		String suTable = name.substring(0, name.lastIndexOf("."));
		
	
		List<PdfFormField> headerList = new ArrayList<PdfFormField>();
		List<PdfFormField> rowList = new ArrayList<PdfFormField>();
		for (Entry<String, PdfFormField> entry : fieldMap.entrySet()) {
			String fName = entry.getKey();
			PdfFormField field = entry.getValue();
			if (fName.startsWith(suTable+".") && !name.equals(fName)){
				PDFFieldAttr fieldAttr = PDFFieldUtil.getPDFFieldAttr(field);
				if (fieldAttr!=null&&fieldAttr.getType()==null) {
					fieldAttr.setType(-10);
				}
				if (!fName.replace(suTable+".", "").contains(".")&&((fieldAttr!=null&&fieldAttr.getType()!=null&&fieldAttr.getType() == 22) || tableType == 10)) {
					headerList.add(entry.getValue());
				}
				if (fieldAttr==null || fieldAttr.getType() != 22 || tableType == 10||fName.replace(suTable+".", "").contains(".")) {				
					rowList.add(entry.getValue());
					rowAllMap.put(fName, entry.getValue());
				}
			}
		}
		Rectangle tableR = pdfDiv.getRect();
		
		this.name = suTable;
		this.tableR = tableR;
		this.headerList = headerList;
		this.rowList = rowList;
		List<PdfFormField> list = new ArrayList<PdfFormField>();
		list.addAll(headerList);
		list.addAll(rowList);
		yList = new ArrayList<Float>();
		xList = new ArrayList<Float>();
		for (PdfFormField pdfFormField : list) {
			Rectangle field = PDFFieldUtil.getRectangle(pdfFormField);
			boolean addxs = true;
			boolean addxe = true;
			for (Float x : xList) {
				if (x - field.getX() < 10 && x - field.getX() > -10) {
					addxs = false;
				}
				if (x - field.getX() - field.getWidth() < 10
						&& x - field.getX() - field.getWidth() > -10) {
					addxe = false;
				}
			}
			if (addxs) {
				xList.add(field.getX());
			}
			if (addxe) {
				xList.add(field.getX() + field.getWidth());
			}

			boolean addys = true;
			boolean addye = true;
			for (Float y : yList) {
				if (y - field.getY() < 10 && y - field.getY() > -10) {
					addys = false;
				}
				if (y - field.getY() - field.getHeight() < 10
						&& y - field.getY() - field.getHeight() > -10) {
					addye = false;
				}
			}
			if (addys) {
				yList.add(field.getY());
			}
			if (addye) {
				yList.add(field.getY() + field.getHeight());
			}
		}
		Comparator comparatorAsc = new Comparator<Float>() {
            @Override
            public int compare(Float o1, Float o2) {
                //升序
                try {
					return o1 - o2 > 0 ? 1: -1;
				} catch (Exception e) {
					e.printStackTrace();
				}
				return 0;
            }
        };
        Comparator comparatorDesc = new Comparator<Float>() {
            @Override
            public int compare(Float o1, Float o2) {
                //升序
                try {
					return o1 - o2 > 0 ? -1: 1;
				} catch (Exception e) {
					e.printStackTrace();
				}
				return 0;
            }
        };
		Collections.sort(xList, comparatorAsc);
		Collections.sort(yList, comparatorDesc);
		headerYRowMap = sortField(headerList);
		rowYRowMap = sortField(rowList);
		table = new Table(getClumArr());
		table.setWidth(20);
		Border ab = new SolidBorder(Color.BLACK, borderW);
		table.setBorder(ab);
		if(!ischild){
			table.setMarginLeft(tableR.getX());
		}else{
			table.setMarginLeft(-0.5f*borderW);
			table.setMarginTop(-0.5f*borderW);
			table.setMarginBottom(-0.5f*borderW);
			table.setBorder(null);
			
		}
		table.setBorder(null);
		table.setPadding(0);
		table.setFixedLayout();
		//默认微软雅黑
		table.setFont(PDFDownloadUtil.getFont(null));
		//table.setFontColor(Color.GREEN);
		insertHeader();
		insertTableList();
	}
	
	
	/**
	 * 分行分列排序
	 * @param list
	 * @return
	 * @throws Exception
	 */
	private static Map<Float, List<PdfFormField>> sortField(List<PdfFormField> list) throws Exception{
		Map<Float, List<PdfFormField>> yMap = new HashMap<Float, List<PdfFormField>>();
		List<Float> yf = new ArrayList<Float>();	
		//y轴分类
		for (PdfFormField pdfFormField : list) {
			Rectangle field = PDFFieldUtil.getRectangle(pdfFormField);
			
			boolean add = true;
			for (Entry<Float, List<PdfFormField>> entry : yMap.entrySet()) {
				if (entry.getKey()-field.getY()-field.getHeight()<10 && entry.getKey()-field.getY()-field.getHeight()>-10) {
					add = false;
					entry.getValue().add(pdfFormField);
				}
			}
			if(add){
				ArrayList<PdfFormField> addList = new ArrayList<PdfFormField>();
				addList.add(pdfFormField);
				yf.add(field.getY()+field.getHeight());
				yMap.put(field.getY()+field.getHeight(), addList);
			}
		}
		
		Collections.sort(yf, new Comparator<Float>() {
            @Override
            public int compare(Float o1, Float o2) {
                //升序
                try {
					return o1 - o2>0? -1: 1;
				} catch (Exception e) {
					e.printStackTrace();
				}
				return 0;
            }
        });
		Map<Float, List<PdfFormField>> yMap2 = new LinkedHashMap<Float, List<PdfFormField>>();
		for (Float float1 : yf) {
			yMap2.put(float1, yMap.get(float1));
		}
		yMap = yMap2;
		for (Entry<Float, List<PdfFormField>> entry : yMap.entrySet()) {
			Collections.sort(entry.getValue(), new Comparator<PdfFormField>() {
	            @Override
	            public int compare(PdfFormField o1, PdfFormField o2) {
	                //升序
	                try {
						return PDFFieldUtil.getRectangle(o1).getX() - PDFFieldUtil.getRectangle(o2).getX()>0? 1: -1;
					} catch (Exception e) {
						e.printStackTrace();
					}
					return 0;
	            }
	        });
		}
		return yMap;
	}
	
	/**
	 * 获取表格每一列的划分
	 * @return
	 * @throws Exception
	 */
	public float[] getClumArr() throws Exception{
		Float last = null;
		float[] pointColumnWidths  = new float[xList.size()-1];
		float coutWid = xList.get(xList.size()-1)-xList.get(0);
		int i = 0;
		for (Float x : xList) {
			if (last == null) {
				last = x;
			}else{
				float columnWidth = (x - last)*(tableR.getWidth()-1)/coutWid;
				pointColumnWidths[i] = columnWidth;
				last = x;
				i++;
			}
		}
		return pointColumnWidths;
	}
	
	/**
	 * 跟基表单生成cell
	 * @param pdfFormField
	 * @return
	 * @throws Exception
	 */
	public Cell conVertCell(PdfFormField pdfFormField) throws Exception{
		Rectangle rect =  PDFFieldUtil.getRectangle(pdfFormField);
		float ys = rect.getY() + rect.getHeight();
		float ye = rect.getY();
		int ysi = 0;
		int yei = 0;
		
		for (int i=0; i<yList.size();i++) {
			Float y = yList.get(i);
			if (ys-y<10 && ys-y>-10) {
				ysi = i;
			}
			if (ye-y<10 && ye-y>-10) {
				yei = i;
			}
			
		}
		float xs = rect.getX();
		float xe = rect.getX() + rect.getWidth();
		int xsi = 0;
		int xei = 0;
		for (int i=0; i<xList.size();i++) {
			Float x = xList.get(i);
			if (xs-x<10 && xs-x>-10) {
				xsi = i;
			}
			if (xe-x<10 && xe-x>-10) {
				xei = i;
			}
		}
		Cell cell = new Cell(yei - ysi, xei - xsi);
		return cell;
	}
	
	/**
	 * 插入头
	 * @throws Exception
	 */
	public void insertHeader() throws Exception{
		System.out.println(name);
		//头
		Map<Float, List<PdfFormField>> yMap = headerYRowMap;
		for (Entry<Float, List<PdfFormField>> entry : yMap.entrySet()) {
			List<PdfFormField> alist = entry.getValue();
			for (PdfFormField pdfFormField : alist) {
				String value = pdfFormField.getValueAsString();
				PDFFieldAttr pDFFieldAttr = PDFFieldUtil.getPDFFieldAttr(pdfFormField);
				if (pDFFieldAttr!=null && pDFFieldAttr.getHeaderFieldType()!=null && pDFFieldAttr.getHeaderFieldType() == 20) {
					String lastName = pdfFormField.getPdfObject().getAsString(PdfName.T).getValue();
					value = attrMap.get(lastName).toString();
				}	
				Cell cell  =  conVertCell(pdfFormField);
				cell.setFont(PDFDownloadUtil.getFont(pdfFormField));
				cell.setTextAlignment(TextAlignment.CENTER)
	            .setVerticalAlignment(VerticalAlignment.MIDDLE);
				cell.setPadding(0);
				 
				 if (value != null) {
					 if (pDFFieldAttr != null && tableType !=10&&pDFFieldAttr.getContentType() != null && !StringUtils.isBlank(value.toString())) {
						 if(pDFFieldAttr.getContentType() == 10){
								PDFFieldUtil.insertBarCode(cell, pdfFormField, value.toString(), pdfDoc);
						 }else if(pDFFieldAttr.getContentType() == 20){
								Image image = PDFFieldUtil.getImage(pdfFormField, value);
								Rectangle ret = PDFFieldUtil.getRectangle(pdfFormField);
								image.setWidth(0.98f*ret.getWidth());
								 cell.add(image);
							}

					 }else{
						 cell.add(value.toString());
					 }

				 }else{
					 cell.add("");
				 }
				
				if(pageHeader!=20){
					//cell.setBorder(null);
					table.addHeaderCell(cell);
				}else{
					table.addCell(cell);
				}
			}
		}
	}
	
	
	/**
	 * 插入表格数据
	 * @throws Exception
	 */
	public void insertTableList() throws Exception{
		String suName = name;
		if (name.contains(".")) {
			String[] arrtN = name.split("\\.");
			int kj = arrtN.length-1;
			suName = arrtN[kj];
		}
		Object listObject = attrMap.get(suName);
		List dataObjectList = new ArrayList();
		if(listObject instanceof List){
			dataObjectList = (List) listObject;
		}
		for(int i=0; i<dataObjectList.size(); i++){
			Object obj =  dataObjectList.get(i);
			Map<String, Object> rowAttrMap;
			if (obj instanceof Map) {
				rowAttrMap = (Map<String, Object>) obj;
			} else {
				rowAttrMap = DataUtil.objToMap(obj);
			}		
			insertRow(table, rowAttrMap);
		}
		
		

	}
	
	/**
	 * 插入表格数据的一行
	 * @param table
	 * @param rowAttrMap
	 * @throws Exception
	 */
	private void insertRow(Table table, Map<String, Object> rowAttrMap) throws Exception{
		Map<Float, List<PdfFormField>> yMap = rowYRowMap;
		Object frontColorObj = rowAttrMap.get("frontColor");
		Color frontColor = null;
		if (frontColorObj != null && frontColorObj instanceof  Color) {
			frontColor = (Color) frontColorObj;
		}
		for (Entry<Float, List<PdfFormField>> entry : yMap.entrySet()) {
			List<PdfFormField> alist = entry.getValue();
			for (PdfFormField pdfFormField : alist) {
				 String fieldName = pdfFormField.getFieldName().toString();
				 String subName = fieldName.replace(name+".", "");	
				 PDFFieldAttr fieldAttr = PDFFieldUtil.getPDFFieldAttr(pdfFormField);
				if (!subName.contains(".")) {
					 String attyName = pdfFormField.getPdfObject().getAsString(PdfName.T).getValue();
					 Object attr = rowAttrMap.get(attyName);
					 Cell cell  =  conVertCell(pdfFormField);
					 cell
		             .setTextAlignment(TextAlignment.CENTER)
		             .setVerticalAlignment(VerticalAlignment.MIDDLE);
					 
					 cell.setKeepTogether(true);
					 cell.setPadding(0);
					 cell.setMargin(10);
					 if (null != frontColor) {
						 cell.setFontColor(frontColor);
					 }
					 if (attr != null) {
						 if (fieldAttr != null && fieldAttr.getContentType() != null && fieldAttr.getContentType() == 10  && !StringUtils.isBlank(attr.toString())) {
								PDFFieldUtil.insertBarCode(cell, pdfFormField, attr.toString(), pdfDoc);
						 }else{
							 cell.add(attr.toString());
						 }

					 }else{
						 cell.add("");
					 }
					 table.addCell(cell);
				 }else if(fieldAttr!=null &&  fieldAttr.getType()!=null&&fieldAttr.getType()==20 && !subName.substring(0, subName.lastIndexOf(".")).contains(".")){
					 Rectangle rectangle = PDFFieldUtil.getRectangle(pdfFormField);
					 if(rectangle.getWidth()>tableR.getWidth()){
						 rectangle.setWidth(tableR.getWidth());
					 }
					 MyTable myTable = new MyTable(true,rowAttrMap, new PdfDiv("table", rectangle, fieldName),  rowAllMap, pdfDoc);
					 Cell cell  =  conVertCell(pdfFormField);
					 cell
		             .setTextAlignment(TextAlignment.CENTER)
		             .setVerticalAlignment(VerticalAlignment.MIDDLE);
					 cell.add(myTable.table);
					 cell.setPadding(0);
					 cell.setMargin(10);
					 if (null != frontColor) {
						 cell.setFontColor(frontColor);
					 }
					 table.addCell(cell);
				 }
			}
		}
	}
}
