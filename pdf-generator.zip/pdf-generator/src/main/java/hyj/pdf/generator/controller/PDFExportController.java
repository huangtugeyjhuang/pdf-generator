package hyj.pdf.generator.controller;

import hyj.pdf.generator.ftpdf.PDFDownloadUtil;
import hyj.pdf.generator.ftpdf.PDFTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.kernel.color.Color;

@RestController
@RequestMapping("/api/pdfExport")
public class PDFExportController {

	@GetMapping("template")
	public void exportByTemplate() throws IOException {
		
		List<Map<String,Object>> orders = new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> itemList = new ArrayList<Map<String,Object>>();
		for (int i=0; i<5; i++) {
			Map<String,Object> map = new  HashMap<String, Object>();
			map.put("no", i);
			map.put("title", "标题"+i);
			itemList.add(map);
		}
		for (int i=0; i<5; i++) {
			Map<String,Object> map = new  HashMap<String, Object>();
			map.put("itemList", itemList);
			map.put("ono", i);
			map.put("on2", "C:/Users/hyj/Desktop/pdf/picture/my.jpg");
			if (i<3) {
				map.put("frontColor", Color.GREEN);
			}
			orders.add(map);
		}
		
		Map<String, Object> dataObject = new HashMap<String, Object>();
		dataObject.put("orderCode", "9876511569413");
		dataObject.put("title", "标题11122");
		dataObject.put("myImage", "C:/Users/hyj/Desktop/pdf/picture/my.jpg");
		
		dataObject.put("currentDate", "2019-05-15");
		dataObject.put("itemList", itemList);
		dataObject.put("orderList", orders);
		dataObject.put("itemList2", itemList);
		PDFDownloadUtil.downLoadTablePDF(dataObject, "pdftemplate/dispatchTmplate.pdf");
    }
    
    /**
     * 纵向合并
     * @param ids
     * @throws IOException
     */
    @GetMapping("pdfMerger")
   	public void pdfm(String ids) throws IOException {
   		List<PDFTemplate> pdfTemplateList = new ArrayList<PDFTemplate>();
   		pdfTemplateList.add(new PDFTemplate("C:/Users/hyj/Desktop/pdf/exportwordByIds.pdf", 1, 2));
   		pdfTemplateList.add(new PDFTemplate("C:/Users/hyj/Desktop/pdf/dispatchTmplate.pdf", null, null));
   		pdfTemplateList.add(new PDFTemplate("C:/Users/hyj/Desktop/pdf/exportwordByIds.pdf", 3, 7));
		PDFDownloadUtil.pdfMerger(pdfTemplateList );
    }
    
    /**
     * 横向合并
     * @param ids
     * @throws IOException
     */
    @GetMapping("pdfHorizontalMerger")
   	public void pdfHorizontalMerger(String ids) throws IOException {
   		List<PDFTemplate> pdfTemplateList = new ArrayList<PDFTemplate>();
   		pdfTemplateList.add(new PDFTemplate("C:/Users/hyj/Desktop/pdf/exportwordByIds.pdf", 1, 2));
   		pdfTemplateList.add(new PDFTemplate("C:/Users/hyj/Desktop/pdf/exportwordByIds.pdf", 1, 2));
		PDFDownloadUtil.pdfHorizontalMerger(pdfTemplateList );
    }
}
