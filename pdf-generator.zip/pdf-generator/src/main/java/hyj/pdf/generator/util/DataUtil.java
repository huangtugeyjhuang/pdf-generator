package hyj.pdf.generator.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;


@Slf4j
public class DataUtil {
	

	
	/**
	 * 将对象转换成maps
	 * @param obj
	 * @return
	 */
	public static Map<String, Object> objToMap(Object obj) {
		 if (obj == null)  
	            return null;    
		Map<String, Object> map = new HashMap<String, Object>();
		// 获取f对象对应类中的所有属性域
		List<Field> fieldList = new ArrayList<>() ;
		Class tempClass = obj.getClass();
		while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
		      fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
		      tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
		}
		//Field[] fields = obj.getClass().getDeclaredFields();
		for (Field field : fieldList) {
			String varName = field.getName();
			try {	
				boolean accessFlag = field.isAccessible();
				field.setAccessible(true);
				Object o = field.get(obj);
				if (o != null){
					map.put(varName, o);
				}
				field.setAccessible(accessFlag);
			} catch (IllegalArgumentException | IllegalAccessException ex) {
				ex.printStackTrace();
			} 
		}
		return map;
	}
	
	public static List<Map<String, Object>>  objListToMapList(List objList) {
		List<Map<String, Object>> rsList = new ArrayList<Map<String,Object>>();
		for (Object object : objList) {
			rsList.add(objToMap(object));
		}
		return rsList;
	}
	/**
	 * Map转对象
	 * @param map
	 * @param beanClass
	 * @return
	 * @throws Exception
	 */
	public static <TargetType> TargetType mapToObject(Map<String, Object> map, Class<TargetType> beanClass) {    
        if (map == null)  
            return null;    
        TargetType obj = null;
        try {	
        	obj = beanClass.newInstance();  
    		List<Field> fieldList = new ArrayList<>() ;
    		Class tempClass = obj.getClass();
    		while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
    		      fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
    		      tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
    		}
            //Field[] fields = obj.getClass().getDeclaredFields();   
            for (Field field : fieldList) {    
                int mod = field.getModifiers();    
                if(Modifier.isStatic(mod) || Modifier.isFinal(mod)){    
                    continue;    
                }    
      
                field.setAccessible(true);    
                field.set(obj, map.get(field.getName()));   
            }   
        }catch (InstantiationException | IllegalAccessException ex) {
			ex.printStackTrace();
		} 
        return obj;    
    }    
	
	public static <TargetType> List<TargetType> mapListToObjectList(List<Map<String, Object>> mapList, Class<TargetType> beanClass){
		List<TargetType> list = new ArrayList<TargetType>();
		for (Map<String, Object> map : mapList) {
			list.add(mapToObject(map, beanClass));
		}
		return list;
	}

	/**
	 * Map转对象
	 * @param map
	 * @param beanClass
	 * @return
	 * @throws Exception
	 */
	public static <TargetType> TargetType stringMapToObject(Map<String, String> map, Class<TargetType> beanClass) {    
        if (map == null)  
            return null;    
        TargetType obj = null;
        try {	
        	obj = beanClass.newInstance();  
            Field[] fields = obj.getClass().getDeclaredFields();   
            for (Field field : fields) {    
                int mod = field.getModifiers();    
                if(Modifier.isStatic(mod) || Modifier.isFinal(mod)){    
                    continue;    
                } 
                field.setAccessible(true);    
                String value = map.get(field.getName());
                if (value != null && "Integer".equals(field.getType().getSimpleName())) {
                	field.set(obj, Integer.valueOf(value));   
                }else{
                	field.set(obj, value);   
                }
                
            }   
        }catch (InstantiationException | IllegalAccessException ex) {
			ex.printStackTrace();
		} 
        return obj;    
    }    
	
	public static <TargetType> Class<? extends Class> getClassByFieldName(Class<TargetType> beanClass, String fieldName) {    
        TargetType obj = null;
        try {	
        	obj = beanClass.newInstance();  
            Field[] fields = obj.getClass().getDeclaredFields();   
            for (Field field : fields) {    
                int mod = field.getModifiers();    
                if(Modifier.isStatic(mod) || Modifier.isFinal(mod)){    
                    continue;    
                } 
               
                field.setAccessible(true); 
                String name = field.getType().getName();
                if(name.equals(fieldName)){
                	return field.getType().getClass();
                }
                
            }   
        }catch (InstantiationException | IllegalAccessException ex) {
			ex.printStackTrace();
		} 
        return null;    
    }    

	
	
	/**
	 * 反射创建arg2 并将arg1 值 给予 arg1
	 * @Title: copyProperties
	 * @Description: 
	 * @author liufutong
	 * @param @param arg1
	 * @param @param arg2
	 * @param @return    设定文件
	 * @return Arg2Type    返回类型
	 * @throws
	 */
	public static <Arg1Type,Arg2Type> Arg2Type copyProperties(Arg1Type arg1,Class<Arg2Type> arg2){
		Arg2Type result = null;
		try {
			result = arg2.newInstance();
			BeanUtils.copyProperties(arg1, result);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		} 
		return  result;
	}
	
	
	/**
	 *  * list数据类型转换
	 * @param sourceList
	 * @param targetClass
	 * @return
	 */
	public static <TargetType, SourceType> List<TargetType> dataListConvert(
			List<SourceType> sourceList, Class<TargetType> targetClass) {
		if(sourceList == null){
			return null;
		}
		List<TargetType> result = new ArrayList<>();
		try {
			for (Object source : sourceList) {
				result.add( copyProperties(source,targetClass));
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
		return result;
	}
	/**
	 * 数据类型转换
	 * @param source
	 * @param targetClass
	 * @return
	 */
	public static <TargetType, SourceType> TargetType  dataConvert(SourceType source,Class<TargetType> targetClass){
		return copyProperties(source,targetClass);
	}
	/**
	 * 将对象封装成
	 * @param obj
	 * @return
	 */
	public static <ObjType> List<ObjType> convertList(ObjType obj){
		List<ObjType> result = new ArrayList<ObjType>();
		result.add(obj);
		return result;
	}



}
