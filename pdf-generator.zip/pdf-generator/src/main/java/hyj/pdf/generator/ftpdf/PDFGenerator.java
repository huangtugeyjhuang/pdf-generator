package hyj.pdf.generator.ftpdf;

import hyj.pdf.generator.util.DataUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.layout.LayoutArea;
import com.itextpdf.layout.property.AreaBreakType;
import com.itextpdf.layout.property.HorizontalAlignment;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.renderer.RootRenderer;

public class PDFGenerator {

	public  float moveY = 0;
	public  Object dataObject = null;
	Map<String, Object> attrMap;
	public  Document document = null;
	public  PdfDocument pdfDoc = null;
	public  PdfDocument srcDoc = null;
	public  Float docMarginTop = 16f;
	public  Float docMarginBottom = 16f;
	PdfDiv headerDiv;
	PdfDiv footerDiv;
	/**
	 * 排序后
	 */
	Map<String, PdfFormField> fieldMap = null;
	
	PageSize pageSize;

	public PDFGenerator(Object dataObject, String templatePath){
		HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
		this.dataObject = dataObject;
		if (dataObject instanceof Map) {
			attrMap = (Map<String, Object>) dataObject;
		} else {
			attrMap = DataUtil.objToMap(dataObject);
		}
		Long ct = System.currentTimeMillis();
		try {
			File file = new File(templatePath);
			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
			srcDoc = new PdfDocument(new PdfReader(file));
			pdfDoc = new PdfDocument(new PdfWriter(toClient));
			document = new Document(pdfDoc);
			document.setMargins(0, 0, 0, 0);
			pageSize = new PageSize(srcDoc.getFirstPage().getPageSize());
			pdfDoc.addNewPage(pageSize);
			fieldMap = getSortMap();
			initHeaderFooter();
			document.setMargins(docMarginTop, 0, docMarginBottom, 0);
			pdfDoc.addEventHandler(PdfDocumentEvent.START_PAGE, new MyIEventHandler(this));
			insertHeaderFooter();
			copy();	
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			if(srcDoc!=null){
				srcDoc.close();
			}
			if(pdfDoc!=null){
				pdfDoc.close();
			}
		}
		System.out.println("渲染耗时" + (System.currentTimeMillis() - ct));
	}
	
	/**
	 * 插入表头表位
	 * @throws Exception
	 */
	public void insertHeaderFooter() throws Exception{
		moveY = 0;
		copyAsDiv(headerDiv);
		copyAsDiv(footerDiv);
	}
	
	/**
	 * 获取按位置排序后的表单
	 * @param srcDoc
	 * @return
	 */
	private  Map<String, PdfFormField> getSortMap(){
		Map<String, PdfFormField> fieldMapSource = PdfAcroForm.getAcroForm(srcDoc, true).getFormFields();
		Map<String, Float> yMap = new LinkedHashMap<String, Float>();
		Map<String, PdfFormField> sortFieldMap = new LinkedHashMap<String, PdfFormField>();
		int fieldCount = 0;
		for (Entry<String, PdfFormField> entry : fieldMapSource.entrySet()) {
			String name = entry.getKey();
			PdfFormField field = entry.getValue();
			try {
				Rectangle rectangle = PDFFieldUtil.getRectangle(field);
				yMap.put(name, rectangle.getHeight() + rectangle.getY());
				fieldCount++;
			} catch (Exception e) {
			}
		}
		for(int i=0; i<fieldCount; i++){
			float max = 0;
			String name = "";
			for (Entry<String, Float> entry : yMap.entrySet()) {
				if(entry.getValue() >= max){
					name = entry.getKey();
					max = entry.getValue();
				}
			}
			yMap.remove(name);
			sortFieldMap.put(name, fieldMapSource.get(name));
		}
		return sortFieldMap;
	}

	/**
	 * 复制模板到生成的文件中
	 * @throws Exception
	 */
	private  void copy() throws Exception{
		List<PdfDiv> rectangleList = getRectangleList();
		//复制区域
		for (PdfDiv pdfDiv : rectangleList) {
			Rectangle pectangle = pdfDiv.getRect();
			if(pdfDiv.getDivType().endsWith("div")){
				RootRenderer red = document.getRenderer();
		        LayoutArea crare =  red.getCurrentArea();
		        Rectangle ret = crare.getBBox();
		        moveY = (pectangle.getY()+ pectangle.getHeight())-(ret.getY()+ret.getHeight());
		        //下一页
		        if(pdfDiv.getRect().getY() - moveY <0){
					PageSize pageSize = new PageSize(srcDoc.getFirstPage().getPageSize());
					pdfDoc.addNewPage(pageSize);
					document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
					moveY = pdfDiv.getRect().getY() - (pageSize.getHeight() - pdfDiv.getRect().getHeight());
					insertHeaderFooter();
				}
		        copyAsDiv(pdfDiv);
		        //插入占位
		        insertDiv(pdfDiv);
		       
			}else{
				MyTable myTable = new MyTable(dataObject, pdfDiv, fieldMap, pdfDoc);
				document.add(myTable.table);
			}
		}
	}
	
	/**
	 * 复制一个区域内的文字和表单
	 * @param pdfDiv
	 * @throws Exception
	 */
	private void copyAsDiv(PdfDiv pdfDiv) throws Exception{
		Rectangle rectangle = pdfDiv.getRect();
		PdfFormXObject pageXObject = srcDoc.getFirstPage().copyAsFormXObject(pdfDoc);	
		PdfFormXObject canvasSrc = new PdfFormXObject(rectangle);
        PdfCanvas canvasCopy = new PdfCanvas(canvasSrc, pdfDoc);
        canvasCopy.rectangle(rectangle.getLeft(), rectangle.getBottom(), rectangle.getWidth(), rectangle.getHeight());
        canvasCopy.clip();
        canvasCopy.newPath();
        canvasCopy.addXObject(pageXObject, 0, 0);  
        PdfCanvas canvas = new PdfCanvas(pdfDoc.getLastPage());
        canvas.addXObject(canvasSrc, 0, 0-moveY);
        copyAreFiled(pdfDiv.getRect());
	}
	

	/**
	 * 复制一个区域内的表单
	 * @param rectangle
	 * @throws Exception
	 */
	private void copyAreFiled(Rectangle rectangle) throws Exception {
		Map<String, PdfFormField> rectangleMap = new HashMap<String, PdfFormField>();
		for (Entry<String, PdfFormField> entry : fieldMap.entrySet()) {
			PdfFormField pdfFormField = entry.getValue();
			if (inSide(rectangle,pdfFormField)) {
				rectangleMap.put(entry.getKey(),entry.getValue());
			}
		}
		//没有表
		for (Entry<String, PdfFormField> entry : rectangleMap.entrySet()) {
			PdfFormField pdfFormField = entry.getValue();
			copyField(pdfFormField);
		}
	}
	
	
	
	/**
	 * 插入占位区域
	 * @param pdfDiv
	 * @throws IOException
	 */
	private void insertDiv(PdfDiv pdfDiv) throws IOException{
		Rectangle rectangle = pdfDiv.getRect();
		float h = rectangle.getHeight();
		 Rectangle emtRect = new Rectangle(srcDoc.getFirstPage().getPageSize().getWidth(), h);
	     PdfFormXObject emt = new PdfFormXObject(emtRect);
	     
	     PdfCanvas templateCanvas = new PdfCanvas(emt, pdfDoc);
	     templateCanvas
         .beginText()
         .endText()
         .stroke();
	     Image image = new Image(emt);
	     document.add(image);
	}
	

	/**
	 * 划分区域
	 * @return
	 * @throws Exception
	 */
	private List<PdfDiv> getRectangleList() throws Exception{
		Rectangle currentRectangle = pageSize;
		List<PdfDiv> rectangleList = new ArrayList<PdfDiv>();	
		float xr = currentRectangle.getX();
		float yr = currentRectangle.getY() + docMarginBottom;
		float width = currentRectangle.getWidth();
		float indexY = currentRectangle.getHeight() + yr - docMarginTop - docMarginBottom;
		
		for (Entry<String, PdfFormField> entry : fieldMap.entrySet()) {
			//第一层表
			String name = entry.getKey();
			PdfFormField pdfFormField = entry.getValue();
			PDFFieldAttr fieldAttr = PDFFieldUtil.getPDFFieldAttr(pdfFormField);
			if(fieldAttr!=null && fieldAttr.getType()!=null && (name.contains(".") && !name.substring(0, name.lastIndexOf(".")).contains("."))){
				if(fieldAttr.getType()==20){
					Rectangle table = PDFFieldUtil.getRectangle(pdfFormField);
					Rectangle div = new Rectangle(xr, table.getY() + table.getHeight(),  width, indexY - (table.getY() + table.getHeight()));
					rectangleList.add(new PdfDiv("div", div, null));
					rectangleList.add(new PdfDiv("table", table, name));
					indexY = table.getY();
				}
			}
		}
		return rectangleList;
	}
	
	/**
	 * 初始化头部，尾部
	 * 确定Margin
	 * @throws Exception
	 */
	private void initHeaderFooter() throws Exception{
		for (Entry<String, PdfFormField> entry : fieldMap.entrySet()) {
			//第一层表
			String name = entry.getKey();
			PdfFormField pdfFormField = entry.getValue();
			PDFFieldAttr fieldAttr = PDFFieldUtil.getPDFFieldAttr(pdfFormField);
		
			if(fieldAttr!=null && fieldAttr.getType()!=null && !name.contains(".")){
				Rectangle ret = PDFFieldUtil.getRectangle(pdfFormField);
				if(fieldAttr.getType() == 60){
					//头
					headerDiv = new PdfDiv("header", ret, name);
					docMarginTop = pageSize.getHeight() - ret.getY();
					 System.out.println("头" + JSON.toJSONString(ret));
				}else if(fieldAttr.getType() == 70){
					//尾
					footerDiv = new PdfDiv("footer", ret, name);
					docMarginBottom =  ret.getY() + ret.getHeight() - pageSize.getY();
				}	
			}
		}
	}
	
	
	/**
	 * 是否在区域之内
	 * @param rectangle
	 * @param field
	 * @return
	 */
	private boolean inSide(Rectangle rectangle, PdfFormField field){
		Rectangle fieldRtg;
		try {
			fieldRtg = PDFFieldUtil.getRectangle(field);
			boolean bl = rectangle.getX() <= fieldRtg.getX() && rectangle.getY() <= fieldRtg.getY();
			boolean br = rectangle.getX()+ rectangle.getWidth() >= fieldRtg.getX() + fieldRtg.getWidth() ;
			boolean tl =  rectangle.getY() + rectangle.getHeight() >= fieldRtg.getY() + fieldRtg.getHeight();
			return bl&br&tl;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 将表单复制过去并转换成对应的文字展示
	 * @param pdfFormField
	 * @throws Exception
	 */
	private void copyField(PdfFormField pdfFormField) throws Exception{
		boolean multiline = pdfFormField.isMultiline();
		PdfFont pdfFont = PDFDownloadUtil.getFont(pdfFormField);
		Float pdfFontSize = PDFFieldUtil.getFontSize(pdfFormField);
		Integer justification = PDFFieldUtil.getJustification(pdfFormField);
		
		String attName = pdfFormField.getPdfObject().getAsString(PdfName.T).getValue();
		Object attr = attrMap.get(attName);
		Rectangle rectangle = PDFFieldUtil.getRectangle(pdfFormField);
		rectangle.setY(rectangle.getY() - moveY);
		String val = "";
		if (attr != null) {
			val = attr.toString();
		}
		PDFFieldAttr pDFFieldAttr = PDFFieldUtil.getPDFFieldAttr(pdfFormField);
		if (pDFFieldAttr != null && pDFFieldAttr.getContentType() != null && !StringUtils.isBlank(val)) {
			if (pDFFieldAttr.getContentType() == 10) {
				PDFFieldUtil.insertBarCode(pdfFormField, val, pdfDoc, moveY);
				return;
			}else if(pDFFieldAttr.getContentType() == 20){
				Image image = PDFFieldUtil.getImage(pdfFormField, val);
				image.setFixedPosition(rectangle.getX(), rectangle.getY());
				document.add(image);
				return;
			}
			
			
		}
		
		Paragraph p = new Paragraph(val).setFont(pdfFont)
		.setFixedPosition(pdfDoc.getNumberOfPages(), rectangle.getLeft(), 
		rectangle.getY(), rectangle.getWidth());
		p.setHorizontalAlignment(HorizontalAlignment.CENTER);
		p.setTextAlignment(TextAlignment.CENTER).setFontColor(Color.BLACK);
		
		if (justification == PdfFormField.ALIGN_LEFT) {
			p.setTextAlignment(TextAlignment.LEFT);
		}
		if (justification == PdfFormField.ALIGN_LEFT) {
			p.setTextAlignment(TextAlignment.CENTER);		
		}
		if (justification == PdfFormField.ALIGN_LEFT) {
			p.setTextAlignment(TextAlignment.RIGHT);
		}
		if (!multiline) {
			p.setHeight(rectangle.getHeight());
		}
		p.setFontColor(Color.RED);
		p.setFontSize(pdfFontSize);
		document.add(p);   
	}
}
