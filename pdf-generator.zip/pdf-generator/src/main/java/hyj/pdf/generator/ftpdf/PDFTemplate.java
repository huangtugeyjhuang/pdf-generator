package hyj.pdf.generator.ftpdf;

import java.util.ArrayList;
import java.util.List;

import com.itextpdf.kernel.pdf.PdfDocument;

import lombok.Data;

@Data
public class PDFTemplate {

	String filePath;
	
	Integer startPage;
	
	Integer endPage;
	
	List<Integer> pageNum; 

	public PDFTemplate(String filePath, Integer startPage, Integer endPage) {
		super();
		this.filePath = filePath;
		this.startPage = startPage;
		this.endPage = endPage;
	}
	
	public void initPDFTemplate(PdfDocument srcDoc) {
		if(pageNum != null && pageNum.size() > 0){
			return;
		}
		pageNum = new ArrayList<Integer>();
		int srcPages = srcDoc.getNumberOfPages();
		
		if (startPage == null) {
			startPage = 1;
		}
		if (endPage == null) {
			endPage = srcPages;
		}
		
		if (srcPages<startPage || srcPages<endPage) {
			throw new RuntimeException("起始页数错误");
		}
		
		
		if (endPage >= startPage ){
			//正序	
			for(int i = startPage; i<= endPage; i++){
				pageNum.add(i);
			}
		}else if(endPage <= startPage ){
			//倒序
			for(int i = endPage; i >= 1; i--){
				pageNum.add(i);
			}
		}
	}
	
}
