package hyj.pdf.generator.ftpdf;

import lombok.Data;

/**
 * 定义表单属性
 * @author hyj
 *
 */
@Data
public class PDFFieldAttr {
	
	/**
	 * 类型 10、复制区域  20、表格  21、表行  22表头  30、段落  40、条码    50、图片  60每页头  70每页尾
	 */
	private Integer type; 
	/**
	 * 内容类型  10、条码   20、图片
	 */
	private Integer contentType; 
	/**
	 * 条码类型 
	 * ISBN
	 * BARCODE39
	 */
	private String barCodeType; 
	
	/**
	 *表头表单类型 10固定字段（默认） 20上一级表单
	 */
	private Integer headerFieldType; 
	
	/**
	 * 表格头类型 10带至下一页(默认) 20不带
	 */
	private Integer pageHeader; 
	
	/**
	 * 表格类型 10简单的表格 20复杂的表的
	 */
	private Integer tableType; 
	
	/**
	 * 值
	 */
	private String value; 
	
	
	/**
	 * 字体自适应
	 * 1、换行不缩小字体
	 * 2、缩小字体不换行
	 * 3、缩小字体并换行
	 * 4、不缩小字体不换行
	 */
	private String adjustment;
	

	

}
