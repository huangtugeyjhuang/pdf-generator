package hyj.pdf.generator.ftpdf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.itextpdf.barcodes.Barcode1D;
import com.itextpdf.barcodes.Barcode39;
import com.itextpdf.barcodes.BarcodeEAN;
import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.io.IOException;
import com.itextpdf.io.font.FontProgram;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.io.source.PdfTokenizer;
import com.itextpdf.io.source.RandomAccessFileOrArray;
import com.itextpdf.io.source.RandomAccessSourceFactory;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.DeviceCmyk;
import com.itextpdf.kernel.color.DeviceGray;
import com.itextpdf.kernel.color.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfArray;
import com.itextpdf.kernel.pdf.PdfDictionary;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.kernel.pdf.PdfObject;
import com.itextpdf.kernel.pdf.PdfStream;
import com.itextpdf.kernel.pdf.PdfString;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;

public class PDFFieldUtil {
	public static final int DEFAULT_FONT_SIZE = 12;
	public static final int MIN_FONT_SIZE = 4;
	public static final int DA_FONT = 0;
	public static final int DA_SIZE = 1;
	public static final int DA_COLOR = 2;

	public static final int ALIGN_LEFT = 0;
	public static final int ALIGN_CENTER = 1;
	public static final int ALIGN_RIGHT = 2;
	public static final String DEFAULT_ENCODING = "UniGB-UCS2-H";
	public static final String DEFAULT_FONTPROGRAM = "STSong-Light";
	
	protected static Object[] splitDAelements(String da) throws Exception {
		PdfTokenizer tk = new PdfTokenizer(new RandomAccessFileOrArray(
				new RandomAccessSourceFactory().createSource(PdfEncodings
						.convertToBytes(da, null))));
		List<String> stack = new ArrayList<>();
		Object[] ret = new Object[3];
		try {
			while (tk.nextToken()) {
				if (tk.getTokenType() == PdfTokenizer.TokenType.Comment)
					continue;
				if (tk.getTokenType() == PdfTokenizer.TokenType.Other) {
					String operator = tk.getStringValue();
					if (operator.equals("Tf")) {
						if (stack.size() >= 2) {
							ret[DA_FONT] = stack.get(stack.size() - 2);
							ret[DA_SIZE] = new Float(
									stack.get(stack.size() - 1));
						}
					} else if (operator.equals("g")) {
						if (stack.size() >= 1) {
							float gray = new Float(stack.get(stack.size() - 1));
							if (gray != 0) {
								ret[DA_COLOR] = new DeviceGray(gray);
							}
						}
					} else if (operator.equals("rg")) {
						if (stack.size() >= 3) {
							float red = new Float(stack.get(stack.size() - 3));
							float green = new Float(stack.get(stack.size() - 2));
							float blue = new Float(stack.get(stack.size() - 1));
							ret[DA_COLOR] = new DeviceRgb(red, green, blue);
						}
					} else if (operator.equals("k")) {
						if (stack.size() >= 4) {
							float cyan = new Float(stack.get(stack.size() - 4));
							float magenta = new Float(
									stack.get(stack.size() - 3));
							float yellow = new Float(
									stack.get(stack.size() - 2));
							float black = new Float(stack.get(stack.size() - 1));
							ret[DA_COLOR] = new DeviceCmyk(cyan, magenta,
									yellow, black);
						}
					}
					stack.clear();
				} else {
					stack.add(tk.getStringValue());
				}
			}
		} catch (IOException e) {

		}
		return ret;
	}
	
    /**
     * 获取字体大小
     * @param pdfFormField
     * @return
     * @throws Exception
     */
	public static float getFontSize(PdfFormField pdfFormField) throws Exception {
		
		  PdfDictionary fontDictionary = pdfFormField.getPdfObject();//.getAsDictionary(PdfName.DR);
          PdfString da = fontDictionary.getAsString(PdfName.DA);
          int DA_SIZE = PdfFormField.DA_SIZE; 
          Object dab[] = splitDAelements(da.toUnicodeString());  
          float size = ((Float) dab[DA_SIZE]).floatValue();  
          //默认字体大小为12
          if (size <= 0) {
            size = PdfFormField.DEFAULT_FONT_SIZE;  
          }  
          return size;
	}
	
	/**
	 * 获取位置
	 * @param pdfFormField
	 * @return
	 * @throws Exception
	 */
	public static Rectangle getRectangle(PdfFormField pdfFormField)throws Exception {
		if(pdfFormField == null) {
			Rectangle toMove = new Rectangle(0, 0, 1, 1);
			return toMove;
		}
		PdfDictionary fontDictionary = pdfFormField.getPdfObject();//
		PdfArray pdfArray = (PdfArray) fontDictionary.get(PdfName.Rect);
		float x = Float.parseFloat(pdfArray.get(0).toString());
		float y = Float.parseFloat(pdfArray.get(1).toString());
		float w = Float.parseFloat(pdfArray.get(2).toString()) - x;
		float h = Float.parseFloat(pdfArray.get(3).toString()) - y;
		return new Rectangle(x, y, w, h);
	}
	
	
	/**
	 * 获取对齐方式
	 * @param pdfFormField
	 * @return
	 * @throws Exception
	 */
	public static int getJustification(PdfFormField pdfFormField) throws Exception {
		if(pdfFormField == null) {
			return PdfFormField.ALIGN_CENTER;
		}
		Integer justification = pdfFormField.getJustification();
		if(justification == null || justification<0) {
			justification = PdfFormField.ALIGN_CENTER;
		}
		return justification;
	}
	
	/**
	 * 获取字体
	 * @param pdfFormField
	 * @return
	 * @throws Exception
	 */
	public static PdfFont getFont(PdfFormField pdfFormField) throws Exception{
		PdfDocument document = pdfFormField.getPdfObject().getIndirectReference().getDocument();
		PdfDictionary fontDictionary = pdfFormField.getPdfObject();
		PdfDictionary apDic = fontDictionary.getAsDictionary(PdfName.AP);
		PdfStream asNormal = null;
		if (apDic != null) {
			asNormal = apDic.getAsStream(PdfName.N);
		}
		PdfFont font = null;
		PdfDictionary normalResources = null;
		PdfDictionary defaultResources = null;
		if (document != null) {
			PdfDictionary acroformDictionary = document.getCatalog()
					.getPdfObject().getAsDictionary(PdfName.AcroForm);
			if (acroformDictionary != null) {
				defaultResources = acroformDictionary
						.getAsDictionary(PdfName.DR);
			}
		}
		if (asNormal != null) {
			normalResources = asNormal.getAsDictionary(PdfName.Resources);
		}
		if (defaultResources != null || normalResources != null) {
			PdfDictionary normalFontDic = normalResources != null ? normalResources
					.getAsDictionary(PdfName.Font) : null;
			PdfDictionary defaultFontDic = defaultResources != null ? defaultResources
					.getAsDictionary(PdfName.Font) : null;
			PdfString defaultAppearance = getDefaultAppearance(fontDictionary);
			if ((normalFontDic != null || defaultFontDic != null)
					&& defaultAppearance != null) {
				Object[] dab = splitDAelements(defaultAppearance
						.toUnicodeString());
				PdfName fontName = new PdfName(dab[DA_FONT].toString());
				PdfDictionary requiredFontDictionary = null;
				if (normalFontDic != null
						&& null != normalFontDic.getAsDictionary(fontName)) {
					requiredFontDictionary = normalFontDic
							.getAsDictionary(fontName);
				} else if (defaultFontDic != null) {
					requiredFontDictionary = defaultFontDic
							.getAsDictionary(fontName);
				}
				PdfFont dicFont = document != null ? document
						.getFont(requiredFontDictionary) : PdfFontFactory
						.createFont(requiredFontDictionary);
				font = dicFont;
			} else {

			}
		} else {

		}
		return font;
	}
	
	

	public static PdfString getDefaultAppearance(PdfDictionary fontDictionary) {
		PdfString defaultAppearance = fontDictionary.getAsString(PdfName.DA);
		if (defaultAppearance == null) {
			PdfDictionary parent = getParent(fontDictionary);
			if (parent != null) {
				if (parent.containsKey(PdfName.FT)) {
					defaultAppearance = parent.getAsString(PdfName.DA);
				}
			}
		}
		return defaultAppearance;
	}

	public static PdfDictionary getParent(PdfDictionary fontDictionary) {
		return fontDictionary.getAsDictionary(PdfName.Parent);
	}
	
	/**
	 * 获取提示
	 * @param pdfObject
	 * @return
	 */
	 public static String getFieldTUName(PdfFormField pdfFormField) {
		 PdfString tUNameStr = pdfFormField.getPdfObject().getAsString(PdfName.TU);
		 String attNameTU = tUNameStr == null ? "":tUNameStr.getValue();
	     return attNameTU;
	 }
	 
	 /**
	  * 获取表单属性
	  * @param pdfFormField
	  * @return
	  */
	 public static PDFFieldAttr getPDFFieldAttr(PdfFormField pdfFormField) {
		 String str = getFieldTUName(pdfFormField);
	     return !str.contains("{") ? null : JSON.parseObject(str, PDFFieldAttr.class);
	 }
	 
	
	 public static PdfString getFieldName(PdfDictionary pdfObject) {
	        String parentName = "";
	        PdfDictionary parent = getParent(pdfObject);
	        if (parent != null) {
	            PdfFormField parentField = PdfFormField.makeFormField(getParent(pdfObject), getDocument(pdfObject));
	            PdfString pName = parentField.getFieldName();
	            if (pName != null) {
	                parentName = pName.toUnicodeString() + ".";
	            }
	        }
	        PdfString name = pdfObject.getAsString(PdfName.T);
	        if (name != null) {
	            name = new PdfString(parentName + name.toUnicodeString());
	        }
	        return name;
	    }
	 
	
	 
	 public static PdfDocument getDocument(PdfDictionary pdfObject) {
	        return pdfObject.getIndirectReference().getDocument();
	    }
	 
	 public static Map<String, PdfFormField>  getChildField(PdfFormField formField){
		 Map<String, PdfFormField> feildMap = new HashMap<String, PdfFormField>();
		 PdfArray formFieldArray = formField.getKids();
		 Map<String, PdfFormField> allMap = PdfAcroForm.getAcroForm(getDocument(formField.getPdfObject()), true).getFormFields();
			for (PdfObject pdfObject : formFieldArray) {
				String childName = getFieldName((PdfDictionary) pdfObject).getValue();
				PdfFormField childFormField = allMap.get(childName);
				String name = childFormField.getFieldName().getValue();
				feildMap.put(name, childFormField);
			}
			return feildMap;
	 }
	 
	 /**
	  * 
	  * @param formField
	  * @return
	  */
	 public static Map<String, PdfFormField>  getOnlyChildFieldMap(PdfFormField formField){
		 Map<String, PdfFormField> feildMap = new HashMap<String, PdfFormField>();
		 PdfArray formFieldArray = formField.getKids();
		 Map<String, PdfFormField> allMap = PdfAcroForm.getAcroForm(getDocument(formField.getPdfObject()), true).getFormFields();
			for (PdfObject pdfObject : formFieldArray) {
				String childName = getFieldName((PdfDictionary) pdfObject).getValue();
				PdfFormField childFormField = allMap.get(childName);
				String name = ((PdfDictionary) pdfObject).getAsString(PdfName.T).getValue();
				feildMap.put(name, childFormField);
			}
			return feildMap;
	 }
	
	
	
	 
		
		/**
		 * 递归求合适的行数以及字体大小
		 * @param fit
		 * @param oldFontSize
		 * @param width
		 * @param rows
		 * @param heit
		 * @return
		 */
		public static Float getFitFontSize(int fit, Float oldFontSize, float width, int rows, float heit){
			float length = fit * oldFontSize / FontProgram.UNITS_NORMALIZATION;
			if(heit<oldFontSize*(1.3*rows-0.3)){//(2*rows-1)
				oldFontSize--;
				oldFontSize = getFitFontSize(fit, oldFontSize, width,rows,  heit);
			}
			length = fit * oldFontSize / FontProgram.UNITS_NORMALIZATION;
			//需要折行
			if (length> width*rows*0.95) {//&& rows ==1
				rows++;
				oldFontSize = getFitFontSize(fit, oldFontSize, width,rows,  heit);
			}
			return  oldFontSize;
		}
		
		/**
		 * 插入二维码
		 * @param fieldId
		 * @param value
		 * @param string 
		 */
		public static void insertBarCode(PdfFormField fieldId, String value, PdfDocument pdfDoc, float moveY){
			PDFFieldAttr pDFFieldAttr = PDFFieldUtil.getPDFFieldAttr(fieldId);
			String codeType = "BARCODE39";
			if (pDFFieldAttr != null && !StringUtils.isBlank(pDFFieldAttr.getBarCodeType())) {
				codeType = pDFFieldAttr.getBarCodeType();
			}
			PdfCanvas canvas = new PdfCanvas(pdfDoc.getLastPage());
			PdfArray arr = (PdfArray) fieldId.getPdfObject().get(PdfName.Rect);
			float x = Float.parseFloat(arr.get(0).toString());
			float y = Float.parseFloat(arr.get(1).toString());
			float w = Float.parseFloat(arr.get(2).toString()) - x;
			float h = Float.parseFloat(arr.get(3).toString()) - y;
			Barcode1D code =  new Barcode39(pdfDoc);
			if("ISBN".equals(codeType)){
				code = new BarcodeEAN(pdfDoc);
				code.setBarHeight(h/1.25f);
				value = value.replace("-", "");
				if(value.length()==10){
					value = PDFFieldUtil.getISBN13(value);
				}
				if(value.length()==12){
					code.setCodeType(BarcodeEAN.UPCA);
				}else if ((value.length()!=13)){
					code = new Barcode39(pdfDoc);
				}
			}else{
				code.setBarHeight(h);
				value = value.toUpperCase();
				//code.setFont(null);
			}
			code.setCode(value);
			code.fitWidth(w);
			PdfFormXObject xObject = code.createFormXObject(pdfDoc);
			canvas.saveState();
			canvas.setFillColor(Color.WHITE);
			canvas.rectangle(x, y, w, h);
			canvas.fill();
			canvas.restoreState();
			Rectangle rect = new Rectangle(x, y- moveY, 1f, 1f);
			canvas.addXObject(xObject, rect);	
		}
		
		
		public static void insertBarCode(Cell cell, PdfFormField fieldId, String value, PdfDocument pdfDoc){
			PDFFieldAttr pDFFieldAttr = PDFFieldUtil.getPDFFieldAttr(fieldId);
			String codeType = "BARCODE39";
			if (pDFFieldAttr != null && !StringUtils.isBlank(pDFFieldAttr.getBarCodeType())) {
				codeType = pDFFieldAttr.getBarCodeType();
			}
			PdfArray arr = (PdfArray) fieldId.getPdfObject().get(PdfName.Rect);
			float x = Float.parseFloat(arr.get(0).toString());
			float y = Float.parseFloat(arr.get(1).toString());
			float w = Float.parseFloat(arr.get(2).toString()) - x;
			float h = Float.parseFloat(arr.get(3).toString()) - y;
			Barcode1D code =  new Barcode39(pdfDoc);
			if("ISBN".equals(codeType)){
				code = new BarcodeEAN(pdfDoc);
				code.setBarHeight(h/1.25f);
				value = value.replace("-", "");
				if(value.length()==10){
					value = PDFFieldUtil.getISBN13(value);
				}
				if(value.length()==12){
					code.setCodeType(BarcodeEAN.UPCA);
				}else if ((value.length()!=13)){
					code = new Barcode39(pdfDoc);
				}
			}else{
				code.setBarHeight(h);
				value = value.toUpperCase();
			}
			code.setCode(value);
			code.fitWidth((w-20f)*0.95f);
			code.setBarHeight((w-21f)/3f);
			cell.add(new Image(code.createFormXObject(null, null, pdfDoc)));
			cell.setPaddingTop(10);
	        cell.setPaddingRight(10);
	        cell.setPaddingBottom(10);
	        cell.setPaddingLeft(10);
		}
		
		
		/**
		 * 生成图片
		 * @param fieldId
		 * @param imagePath
		 * @return
		 * @throws Exception
		 */
		public static Image getImage(PdfFormField fieldId, String imagePath) throws Exception{
			Rectangle ret = getRectangle(fieldId);
			 ImageData data = ImageDataFactory.create(imagePath);
			 Image image = new Image(data);
			 image.setWidth(ret.getWidth());
			 //image.setHeight(ret.getHeight());
			 return image;
		}
		
		
		
		/**
		 * 清除pdf上的所有表单，绑定完数据之后调用
		 * @param pdfDoc
		 */
		public static void removeForm(PdfDocument pdfDoc){
			//确认表单输入的数据并 去掉并插入新的表单
			PdfAcroForm.getAcroForm(pdfDoc, true).flattenFields();
			List<String> nameList = new ArrayList<String>();
			Map<String, PdfFormField> feilds = PdfAcroForm.getAcroForm(pdfDoc, true).getFormFields();
			for (Entry<String, PdfFormField> iterable_element : feilds.entrySet()) {
				nameList.add(iterable_element.getKey());
			}
	        for (String string : nameList) {
	        	PdfAcroForm.getAcroForm(pdfDoc, true).removeField(string);
			}
		}
		
		public static String getISBN13(String isbn) {  
		    if (isbn.length() != 10) {  
		        return isbn;  
		    }  
		    isbn = isbn.substring(0, isbn.length() - 1);  
		    isbn = "978" + isbn;  
		    int a = 0;  
		    int b = 0;  
		    int c = 0;  
		    int d = 0;  
		    for (int i = 0; i < isbn.length(); i++) {  
		        int x = Integer.parseInt(isbn.substring(i, i+1));  
		        if (i % 2 == 0) {  
		            a += x;  
		        } else {  
		            b += x;  
		        }  
		    }  
		    c = a + 3 * b;  
		    d = 10 - c % 10;  
		    isbn = isbn + d;  
		    return isbn;  
		}  
}
