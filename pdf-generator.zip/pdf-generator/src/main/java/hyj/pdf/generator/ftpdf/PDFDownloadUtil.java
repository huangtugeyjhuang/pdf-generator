package hyj.pdf.generator.ftpdf;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.io.font.FontProgram;
import com.itextpdf.io.font.FontProgramFactory;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject;
import com.itextpdf.layout.Document;
@Slf4j
public class PDFDownloadUtil{
	/**
	 * 模板文件和模板路径
	 */
	public static String FONT_PATH = "C:/Users/hyj/Desktop/pdf/fonts/";
	

	public static  Map<String, FontProgram > fontProgramMap = new HashMap<String, FontProgram>();


	public static void downLoadTablePDF(Object dataObject, String templatePath){
		new PDFGenerator(dataObject, templatePath);	
	}
	
	/**
	 * 合并pdf
	 * @param pdfTemplateList
	 */
	public static void  pdfMerger(List<PDFTemplate> pdfTemplateList){
		HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
		Long ct = System.currentTimeMillis();
		List<PdfDocument> pdfDocumentList = new ArrayList<PdfDocument>();	
		PdfDocument pdfDoc = null;
		try {
			for (PDFTemplate pdfTemplate : pdfTemplateList) {
				File file = new File(pdfTemplate.getFilePath());
				OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
				PdfDocument srcDoc = new PdfDocument(new PdfReader(file));
				pdfTemplate.initPDFTemplate(srcDoc);
				pdfDocumentList.add(srcDoc);
				if(pdfDoc == null) {
					pdfDoc =new PdfDocument(new PdfWriter(toClient));
					pdfDocumentList.add(pdfDoc);
				}
				pdfDocumentList.add(srcDoc);
				for(int i = 0; i < pdfTemplate.getPageNum().size(); i++){
					Integer pageNum = pdfTemplate.getPageNum().get(i);
					System.out.println("页数" + pageNum+pdfTemplate.getFilePath());
					PdfPage p = srcDoc.getPage(pageNum);
					Rectangle pageRectangle = p.getPageSize();
					pdfDoc.addNewPage(new PageSize(pageRectangle));
					copyByRectangle(pageRectangle, srcDoc, pdfDoc, 0,0);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			for (PdfDocument pdfDocument : pdfDocumentList) {
				if(pdfDocument != null){
					pdfDocument.close();
				}
			}
		}
		System.out.println("耗时" + (System.currentTimeMillis() - ct));
	}
	
	
	
	/**
	 * 水平合并pdf
	 * @param pdfTemplateList
	 */
	public static void  pdfHorizontalMerger(List<PDFTemplate> pdfTemplateList){
		HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
		Long ct = System.currentTimeMillis();
		List<PdfDocument> pdfDocumentList = new ArrayList<PdfDocument>();	
		PdfDocument pdfDoc = null;
		int maxPage = 1;
		try {
			//打开文件初始化
			for (PDFTemplate pdfTemplate : pdfTemplateList) {
				File file = new File(pdfTemplate.getFilePath());
				OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
				PdfDocument srcDoc = new PdfDocument(new PdfReader(file));
				pdfDocumentList.add(srcDoc);
				if(pdfDoc == null) {
					pdfDoc =new PdfDocument(new PdfWriter(toClient));
				}
				pdfTemplate.initPDFTemplate(srcDoc);
				int page = pdfTemplate.getPageNum().size();
				if (maxPage < page) {
					maxPage = page;
				}
			}
			float maxw = 0; 
			float maxh = 0; 
			//生成maxPage页新文挡
			for(int i=0; i < maxPage; i++){
				float w = 0; 
				float h = 0; 
				List<PdfPage> pageList = new ArrayList<PdfPage>();
				//计算页面大小
				for (int j=0; j< pdfDocumentList.size(); j++) {
					PdfDocument pdfDocument = pdfDocumentList.get(j);
					PDFTemplate pDFTemplate = pdfTemplateList.get(j);
					Integer pageNum = pDFTemplate.getPageNum().get(i);
					PdfPage page = null;
					if(pageNum != null){
						page = pdfDocument.getPage(pageNum);
						pageList.add(page);
						Rectangle ret = page.getPageSize();
						w += ret.getWidth();
						h = h < ret.getHeight() ? ret.getHeight() : h;
					}
				}
				if(w > maxw) maxw = w;
				if(h > maxh) maxh = h;
				
				//生成合并的一个页面
				PageSize pageSize = new PageSize(new Rectangle(maxw, maxh));
				pdfDoc.addNewPage(pageSize);
				float indexX = 0;
				for (PdfPage pdfPage : pageList) {
					Rectangle pageRectangle = pdfPage.getPageSize();
					PdfDocument srcDoc = pdfPage.getDocument();
					copyByRectangle(pageRectangle, srcDoc, pdfDoc,indexX,0);
			        indexX += pageRectangle.getWidth();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			pdfDoc.close();
			for (PdfDocument pdfDocument : pdfDocumentList) {
				if(pdfDocument != null){
					pdfDocument.close();
				}
			}
		}
		System.out.println("耗时" + (System.currentTimeMillis() - ct));
	}
	
	/**
	 * 复制区域
	 * @param rectangle
	 * @param srcDoc
	 * @param pdfDoc
	 * @param moveX
	 * @param moveY
	 * @throws IOException
	 */
	public static void copyByRectangle(Rectangle rectangle, PdfDocument srcDoc, PdfDocument pdfDoc, float moveX,  float moveY) throws IOException{
		PdfFormXObject pageXObject = srcDoc.getFirstPage().copyAsFormXObject(pdfDoc);	
		PdfFormXObject canvasSrc = new PdfFormXObject(rectangle);
        PdfCanvas canvasCopy = new PdfCanvas(canvasSrc, pdfDoc);
        
		canvasCopy.rectangle(rectangle.getLeft(), rectangle.getBottom(), rectangle.getWidth(), rectangle.getHeight());
        canvasCopy.clip();
        canvasCopy.newPath();
        canvasCopy.addXObject(pageXObject, 0, 0);     
        PdfCanvas canvas = new PdfCanvas(pdfDoc.getLastPage());
        canvas.addXObject(canvasSrc, moveX, moveY);
	}
	
	
	
	
	/**
	 * 获取表单
	 * @param fieldId
	 * @return
	 * @throws Exception
	 */
	public static synchronized PdfFont getFont(PdfFormField fieldId) throws Exception{	
		String fontName = "MicrosoftYaHei";
		if (fieldId != null) {
			fontName = PDFFieldUtil.getFont(fieldId).getFontProgram().getFontNames().getFontName();	
		}
		FontProgram fontProgram = null;
		if (fontProgramMap.containsKey(fontName)) {
			fontProgram = fontProgramMap.get(fontName);
		}else{
			String path = FONT_PATH +fontName+".ttf";
			if(!new File(path).exists()){
				path = FONT_PATH +"MicrosoftYaHei.ttf";
			}
			fontProgram = FontProgramFactory.createFont(path);
			fontProgramMap.put(fontName, fontProgram);
		}
		PdfFont font = PdfFontFactory.createFont(fontProgram, PdfEncodings.IDENTITY_H, false);
		return font;
	 }
}
