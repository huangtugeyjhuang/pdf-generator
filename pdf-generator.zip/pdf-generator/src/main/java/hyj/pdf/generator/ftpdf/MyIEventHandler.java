package hyj.pdf.generator.ftpdf;

import com.itextpdf.kernel.events.Event;
import com.itextpdf.kernel.events.IEventHandler;

public class MyIEventHandler implements IEventHandler{
	PDFGenerator pDFGenerator;
	
	public MyIEventHandler(PDFGenerator pDFGenerator) {
		super();
		this.pDFGenerator = pDFGenerator;
	}

	@Override
	public void handleEvent(Event event) {
		System.out.println("aaaaa");
		try {
			pDFGenerator.insertHeaderFooter();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
