package hyj.pdf.generator.ftpdf;

import lombok.Data;

import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.kernel.geom.Rectangle;

@Data
public class PdfDiv {
	/**
	 * 分区类型
	 * div
	 * table
	 * 每页开头header
	 * 每页结尾footer
	 */
	private String divType;
	
	/**
	 * 所占区域
	 */
	private Rectangle rect;
	
	/**
	 * 区域（表名）
	 * 如itemList.table
	 */
	private String name;
	

	
	public PdfDiv(String divType, Rectangle rect, String name) {
		super();
		this.divType = divType;
		this.rect = rect;
		this.name = name;
	}
	
	
}
